from machine import I2C, Pin
import time

# MPU6050'nin I2C adresi
MPU6050_ADDR = 0x68

# I2C bağlantısını başlat
i2c = I2C(scl=Pin(22), sda=Pin(21))

# MPU6050'yi başlat
def init_mpu6050():
    i2c.writeto_mem(MPU6050_ADDR, 0x6B, b'\x00')  # MPU6050'yi uyandır

# MPU6050'den veri oku
def read_mpu6050():
    data = i2c.readfrom_mem(MPU6050_ADDR, 0x3B, 6)  # İvmeölçer verilerini oku
    ax = (data[0] << 8 | data[1]) / 16384.0  # X eksenindeki ivmeölçer verisi
    ay = (data[2] << 8 | data[3]) / 16384.0  # Y eksenindeki ivmeölçer verisi
    az = (data[4] << 8 | data[5]) / 16384.0  # Z eksenindeki ivmeölçer verisi
    return ax, ay, az

# MPU6050'yi başlat
init_mpu6050()

# Ana döngü
while True:
    # MPU6050'den veri oku
    ax, ay, az = read_mpu6050()
    
    # Verileri ekrana yazdır
    print("Ivmeolcer verileri (g):")
    print("X =", ax)
    print("Y =", ay)
    print("Z =", az)
    
    # Kısa bir süre bekleyin
    time.sleep(0.5)

